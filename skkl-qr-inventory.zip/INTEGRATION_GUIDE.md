# QR-First Inventory — Integration Guide (SKKL ERP)

Drop-in addition to the EXISTING codebase. No new app, no folder restructure, no renames.
Every file below lands inside a module you already have.

## File placement (copy as-is)

```
docs/FIRESTORE_QR_SCHEMA.md                         # reference
firestore.rules.additions                           # MERGE into firestore.rules
firestore.indexes.additions.json                    # MERGE into firestore.indexes.json
src/firebase/collections.additions.js               # MERGE keys into src/firebase/collections.js COL
src/firebase/items.js                               # NEW data-layer file (firebase layer)
src/shared/models/ids.js
src/shared/models/item.js
src/shared/models/itemMovement.js
src/shared/models/itemRepair.js
src/shared/models/auditLog.js
src/modules/inventory/lib/qrIdentity.js
src/modules/inventory/hooks/useItem.js
src/modules/inventory/hooks/useItemByQr.js
src/modules/inventory/hooks/useItemMovements.js
src/modules/inventory/hooks/useItemRepairs.js
src/modules/inventory/hooks/useCreateItem.js
src/modules/inventory/components/ItemEntryForm.jsx
src/modules/inventory/components/QrScanInput.jsx
src/modules/inventory/components/ItemQrTag.jsx
src/modules/inventory/components/MovementTimeline.jsx
src/modules/inventory/components/RepairHistoryList.jsx
src/modules/inventory/components/AuditTrail.jsx
functions/qrInventory/*                             # NEW functions sub-folder
```

## Prereqs (one-time)

1. **collections.js** — merge `COL_ADDITIONS` into your `COL` object.
2. **AuthProvider** — `useAuth()` must expose `employeeId` (map the signed-in user → an
   `employees/{employeeId}` record). If you don't have it yet, default to `null`; all
   writers tolerate a null employeeId. Add a `branchId`/`counterId` to the user/session
   where available for movement defaults.
3. **firestore.rules** — paste `firestore.rules.additions` blocks inside your existing
   `match /databases/{db}/documents { ... }`. Deploy rules.
4. **indexes** — merge `firestore.indexes.additions.json` `indexes[]` into
   `firestore.indexes.json`; `firebase deploy --only firestore:indexes`.
5. **functions root index.js** — add: `module.exports = { ...require('./qrInventory') };`
   then `firebase deploy --only functions`.

---

## Exact module modifications (additive only)

### 1. Inventory module — wire entry + scan + detail
`src/modules/inventory/pages/Inventory.jsx` (existing) — add an "Add item" panel and a
detail drawer. No structural change; just render the new components:

```jsx
import ItemEntryForm   from '@modules/inventory/components/ItemEntryForm';
import QrScanInput      from '@modules/inventory/components/QrScanInput';
import ItemQrTag        from '@modules/inventory/components/ItemQrTag';
import MovementTimeline from '@modules/inventory/components/MovementTimeline';
import RepairHistoryList from '@modules/inventory/components/RepairHistoryList';
import AuditTrail       from '@modules/inventory/components/AuditTrail';
import useItem          from '@modules/inventory/hooks/useItem';
// ...
const [activeId, setActiveId] = useState(null);
const { item } = useItem(activeId);
// Entry: <ItemEntryForm branchId={branchId} counterId={counterId} onCreated={setActiveId} />
// Scan : <QrScanInput onResolved={(it) => setActiveId(it.itemId)} />
// Detail: when item -> <ItemQrTag item={item} /> + <MovementTimeline itemId={item.itemId} />
//         + <RepairHistoryList itemId={item.itemId} /> + <AuditTrail entityId={item.itemId} />
```

### 2. Billing module — sell by scan, finalize updates items
`src/modules/billing/pages/Billing.jsx` — add `QrScanInput` to add a line by scanning,
and on each cart line store `itemId`. When you write the sale doc, include the ids:

```jsx
// inside the sale payload you already build:
const salePayload = {
  ...existing,
  counterId,
  byEmployeeId: employeeId,
  lineItems: cart.items.map((l) => ({ ...l, itemId: l.itemId })), // itemId = scanned QR
  soldItemIds: cart.items.map((l) => l.itemId).filter(Boolean),
};
// addDoc('sales', salePayload)  → onSaleFinalize CF marks items sold + appends movement/audit.
```
No client-side item mutation needed for the sold flag — the `onSaleFinalize` function owns
it (single source of truth, atomic, audited).

### 3. Repairs module — repair by item identity
`src/modules/repairs/pages/Repairs.jsx` — when creating a repair, write to
`item_repairs` (append-only) with `itemId` from a scan:

```jsx
import { appendRepair } from '@firebase/items';
import { buildRepair, REPAIR_STATUS } from '@shared/models/itemRepair';
// ...
await appendRepair(
  buildRepair({ itemId, issue, karigarId, weightBefore: item.grossWeight, status: REPAIR_STATUS.RECEIVED, receivedAt: serverTimestamp() },
    { shopId, uid: user.uid, employeeId }),
  { shopId, employeeId });
// onRepairWrite CF flips item.status to in_repair and appends repair_in movement.
// On delivery: update the repair doc status -> 'delivered'; CF flips item back to in_stock.
```
QR is never regenerated by repairs even when weight changes.

### 4. Transfers module — branch/counter movement (append-only)
On transfer confirm, for each item call the data-layer change:

```jsx
import { applyItemChange } from '@firebase/items';
import { MOVEMENT_TYPE } from '@shared/models/itemMovement';
for (const itemId of transfer.itemIds) {
  await applyItemChange(itemId,
    { branchId: transfer.toBranchId, counterId: null, status: 'transferred' },
    { type: MOVEMENT_TYPE.TRANSFERRED, refType: 'transfer', refId: transferId, note: `To ${transfer.toBranchId}`, source: 'transfers_module' },
    { shopId, uid: user.uid, employeeId });
}
// After arrival, set status back to 'in_stock' with another applyItemChange (assigned).
```

### 5. Purchases module — generate items on receipt
`src/modules/purchases/pages/Purchases.jsx` — after saving the purchase, loop the lot and
create one item per piece (each gets its own permanent QR):

```jsx
import useCreateItem from '@modules/inventory/hooks/useCreateItem';
const { create } = useCreateItem();
const ids = [];
for (const piece of purchase.pieces) {
  const id = await create({ ...piece, vendorId: purchase.vendorId, branchId: purchase.branchId, sourcePurchaseId: purchaseId });
  if (id) ids.push(id);
}
await updateDoc(doc(db,'purchases',purchaseId), { generatedItemIds: ids });
```

### 6. Orders module — reserve a specific item by QR
When an order is placed against a specific piece, scan it and set status `assigned`:

```jsx
import { applyItemChange } from '@firebase/items';
await applyItemChange(itemId, { status: 'assigned', counterId },
  { type: 'assigned', refType: 'manual', refId: orderId, note: 'Reserved for order', source: 'orders_module' },
  { shopId, uid: user.uid, employeeId });
```

### 7. Printing / Barcode module — tag uses identity QR
`ItemQrTag` already renders via the restored `TagCanvas` + a `PRESET_TEMPLATES` template
and logs each print to `tag_history` (append-only). No change needed in the print engine;
just ensure your bill/label print path can mount `<ItemQrTag item={item} templateId="hang_81x12" />`.
The QR payload is strictly `item.itemId` — `qrIdentity.js` refuses any non-identity payload.

---

## QR-FIRST invariants enforced (where)

| Rule | Enforced by |
|------|-------------|
| QR holds identity only | `qrIdentity.qrPayload()` throws on non-itemId; `buildItemQrMatrix` validates |
| Generated once | `qrId` set at create; `firestore.rules` forbid changing `itemId`/`qrId` on update |
| Never regenerated (repair/transfer/weight/stone/resale/exchange) | All flows call `applyItemChange` (snapshot fields only) — none touch `qrId` |
| Movement history append-only | `item_movements` rules: create only, no update/delete |
| Audit immutable | `audit_logs` rules: create only |
| History preserved forever | items never hard-deleted (rules `allow delete: if false`); status=lost/melted instead |

---

## Implementation order

1. **Schema/rules/indexes** — merge + deploy rules + indexes. (Nothing breaks; new
   collections are additive.)
2. **collections.js** — add COL keys.
3. **models + `src/firebase/items.js` + `qrIdentity.js`** — pure logic, no UI yet.
4. **Cloud Functions** — deploy `qrInventory/*`. Test `allocateItemId` from a scratch call.
5. **Inventory entry + tag** — wire `ItemEntryForm` + `ItemQrTag`; create one test item,
   print its tag, scan it back with `QrScanInput`. Confirm `item_movements` has a `created`
   row and `audit_logs` has `item.created`.
6. **Inventory detail** — add `MovementTimeline` + `RepairHistoryList` + `AuditTrail`.
7. **Purchases → items** — generate items on receipt.
8. **Billing** — sell by scan; verify `onSaleFinalize` flips status + appends movement.
9. **Transfers** — move items between branches; verify append-only movements.
10. **Repairs** — repair flow; verify status flips via `onRepairWrite`, QR unchanged.
11. **Orders** — reserve by QR.
12. **Audit pass** — open any item, confirm full immutable history from entry → sale.

## Verification checklist
- Create item → exactly one `qrGeneratedAt`, `qrId === itemId === docId`.
- Edit weight / add stone → `items.qrId` unchanged; a `weight_change`/`stone_added`
  movement appended; audit entry written.
- Attempt to change `qrId` via console update → **rejected** by rules.
- Sell, transfer, repair, then re-scan the same QR → resolves to the same item with full
  history. QR string identical throughout.
